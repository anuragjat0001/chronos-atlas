// src/components/map/EventPopup.jsx
import { motion } from 'framer-motion';
import { useFilterStore } from '../../store/filterStore';
import { getCategoryColor, getCategoryIcon } from '../../data/historicalEvents';
import { formatYear } from '../../lib/dateUtils';

const IMPACT_LABELS = { HIGH: 'Major Impact', MEDIUM: 'Moderate Impact', LOW: 'Minor Impact' };
const IMPACT_COLORS = { HIGH: '#EF4444', MEDIUM: '#F59E0B', LOW: '#6B7280' };

export default function EventPopup({ event, position, onClose }) {
  if (!event) return null;

  const color = getCategoryColor(event.category);
  const icon = getCategoryIcon(event.category);
  const impactColor = IMPACT_COLORS[event.impact] || IMPACT_COLORS.LOW;

  return (
    <motion.div
      key={event.id}
      initial={{ opacity: 0, scale: 0.88, y: 12 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.88, y: 12 }}
      transition={{ type: 'spring', stiffness: 380, damping: 28 }}
      className="event-popup"
      style={{
        left: position.x,
        top: position.y,
      }}
    >
      {/* Category color bar */}
      <div className="popup-color-bar" style={{ background: color }} />

      <div className="popup-content">
        {/* Header */}
        <div className="popup-header">
          <div className="popup-meta">
            <span className="popup-icon">{icon}</span>
            <span className="popup-year" style={{ color }}>
              {formatYear(event.year)}
            </span>
            <span className="popup-category">
              {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
            </span>
          </div>
          <button onClick={onClose} className="popup-close" aria-label="Close">
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M1 1L11 11M11 1L1 11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        {/* Title */}
        <h3 className="popup-title">{event.title}</h3>

        {/* Location */}
        {event.country && (
          <div className="popup-location">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
              <circle cx="12" cy="9" r="2.5"/>
            </svg>
            <span>{event.country}</span>
          </div>
        )}

        {/* Description */}
        <p className="popup-description">{event.description}</p>

        {/* Footer */}
        <div className="popup-footer">
          <div className="impact-badge" style={{ borderColor: impactColor, color: impactColor }}>
            <span className="impact-dot" style={{ background: impactColor }} />
            {IMPACT_LABELS[event.impact]}
          </div>

          {/* Tags */}
          {event.tags && event.tags.length > 0 && (
            <div className="popup-tags">
              {event.tags.slice(0, 3).map(tag => (
                <span key={tag} className="popup-tag">#{tag}</span>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
