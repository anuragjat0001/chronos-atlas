// src/components/map/MapEngine.jsx
import { useEffect, useRef, useCallback, useState } from 'react';
import { useFilterStore } from '../../store/filterStore';
import { getCategoryColor, getCategoryIcon } from '../../data/historicalEvents';
import { getBoundariesForYear } from '../../data/historicalBoundaries';
import { HISTORICAL_EVENTS } from '../../data/historicalEvents';

let L = null;

export default function MapEngine({ events, currentYear, selectedEvent, hoveredEvent, onEventClick, onEventHover }) {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersLayerRef = useRef(null);
  const boundaryLayerRef = useRef(null);
  const heatmapLayerRef = useRef(null);
  const [mapReady, setMapReady] = useState(false);
  const { showHeatmap, heatmapMode } = useFilterStore();

  // Initialize Leaflet map
  useEffect(() => {
    if (mapInstanceRef.current || !mapRef.current) return;

    // Load Leaflet dynamically (already in index.html as CSS)
    L = window.L;
    if (!L) return;

    const map = L.map(mapRef.current, {
      center: [20, 10],
      zoom: 2.5,
      minZoom: 2,
      maxZoom: 10,
      zoomControl: false,
      attributionControl: false,
      worldCopyJump: true,
    });

    // Dark CartoDB Basemap — no API key required
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png', {
      attribution: '© OpenStreetMap contributors, © CartoDB',
      subdomains: 'abcd',
      maxZoom: 19,
      opacity: 0.85,
    }).addTo(map);

    // Subtle labels overlay
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png', {
      subdomains: 'abcd',
      maxZoom: 19,
      opacity: 0.4,
      zIndex: 10,
    }).addTo(map);

    // Zoom controls — custom positioned
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Attribution — minimal
    L.control.attribution({ position: 'bottomleft', prefix: '' }).addTo(map);

    // Boundary layer group
    boundaryLayerRef.current = L.layerGroup().addTo(map);

    // Markers layer group
    markersLayerRef.current = L.layerGroup().addTo(map);

    mapInstanceRef.current = map;
    setMapReady(true);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update boundary polygons when year changes
  useEffect(() => {
    if (!mapReady || !boundaryLayerRef.current) return;
    L = window.L;

    boundaryLayerRef.current.clearLayers();
    const boundaries = getBoundariesForYear(currentYear);

    boundaries.forEach(boundary => {
      const color = boundary.color || '#94A3B8';
      const opacity = boundary.opacity || 0.3;
      const style = {
        fillColor: color,
        fillOpacity: opacity,
        color: color,
        weight: 1.5,
        opacity: 0.7,
      };

      if (boundary.multiPolygon) {
        // Multiple separate polygons (British Empire etc.)
        boundary.multiPolygon.forEach(coords => {
          const latLngs = coords.map(([lng, lat]) => [lat, lng]);
          L.polygon(latLngs, style)
            .bindTooltip(boundary.name, {
              permanent: false,
              className: 'boundary-tooltip',
              opacity: 0.9,
            })
            .addTo(boundaryLayerRef.current);
        });
      } else if (boundary.coordinates) {
        const latLngs = boundary.coordinates[0].map(([lng, lat]) => [lat, lng]);
        L.polygon(latLngs, style)
          .bindTooltip(boundary.name, {
            permanent: false,
            className: 'boundary-tooltip',
            opacity: 0.9,
          })
          .addTo(boundaryLayerRef.current);
      }
    });
  }, [currentYear, mapReady]);

  // Update event markers
  useEffect(() => {
    if (!mapReady || !markersLayerRef.current) return;
    L = window.L;
    markersLayerRef.current.clearLayers();

    // Group nearby events into clusters (simple distance-based)
    const clusters = clusterEvents(events, 2.5);

    clusters.forEach(cluster => {
      if (cluster.events.length === 1) {
        // Single event marker
        const ev = cluster.events[0];
        const color = getCategoryColor(ev.category);
        const size = ev.impact === 'HIGH' ? 14 : ev.impact === 'MEDIUM' ? 10 : 7;

        const icon = L.divIcon({
          html: createMarkerHTML(color, size, ev.impact, false),
          className: '',
          iconSize: [size + 8, size + 8],
          iconAnchor: [(size + 8) / 2, (size + 8) / 2],
        });

        const marker = L.marker([ev.lat, ev.lon], { icon })
          .addTo(markersLayerRef.current);

        marker.on('click', (e) => {
          const { containerPoint } = e;
          const mapContainer = mapInstanceRef.current.getContainer();
          const rect = mapContainer.getBoundingClientRect();
          onEventClick(ev, rect.left + containerPoint.x, rect.top + containerPoint.y);
        });

        marker.on('mouseover', () => onEventHover(ev));
        marker.on('mouseout', () => onEventHover(null));
      } else {
        // Cluster marker
        const count = cluster.events.length;
        const mainEv = cluster.events[0];
        const icon = L.divIcon({
          html: createClusterHTML(count),
          className: '',
          iconSize: [40, 40],
          iconAnchor: [20, 20],
        });

        const marker = L.marker([cluster.lat, cluster.lon], { icon })
          .addTo(markersLayerRef.current);

        marker.on('click', () => {
          const map = mapInstanceRef.current;
          map.setView([cluster.lat, cluster.lon], Math.min(map.getZoom() + 2, 8), {
            animate: true, duration: 0.5
          });
        });
      }
    });
  }, [events, mapReady, onEventClick, onEventHover]);

  // Heatmap rendering
  useEffect(() => {
    if (!mapReady || !mapInstanceRef.current) return;
    L = window.L;
    const map = mapInstanceRef.current;

    if (heatmapLayerRef.current) {
      map.removeLayer(heatmapLayerRef.current);
      heatmapLayerRef.current = null;
    }

    if (!showHeatmap) return;

    // Generate heatmap points from all events matching category
    const catMap = { war: 'war', science: 'science', disaster: 'disaster', pandemic: 'pandemic' };
    const cat = catMap[heatmapMode] || heatmapMode;
    const heatEvents = HISTORICAL_EVENTS.filter(e =>
      e.category === cat && e.lat && e.lon
    );

    if (heatEvents.length === 0) return;

    // Simple heatmap using canvas overlay
    renderHeatmapCanvas(map, heatEvents, heatmapMode);
  }, [showHeatmap, heatmapMode, mapReady]);

  // Fly to selected event
  useEffect(() => {
    if (!selectedEvent || !mapInstanceRef.current) return;
    if (!selectedEvent.lat || !selectedEvent.lon) return;
    const map = mapInstanceRef.current;
    const currentZoom = map.getZoom();
    map.flyTo(
      [selectedEvent.lat, selectedEvent.lon],
      Math.max(currentZoom, 4),
      { animate: true, duration: 1.0 }
    );
  }, [selectedEvent]);

  return (
    <div className="map-wrapper">
      <div ref={mapRef} className="map-container" />
      {!mapReady && (
        <div className="map-loading">
          <div className="map-loading-spinner" />
          <span>Loading map...</span>
        </div>
      )}
    </div>
  );
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function createMarkerHTML(color, size, impact, isSelected) {
  const glow = impact === 'HIGH' ? `0 0 12px ${color}80` : 'none';
  const pulseClass = impact === 'HIGH' ? 'marker-pulse' : '';
  return `
    <div class="event-marker ${pulseClass}" style="
      width: ${size + 8}px;
      height: ${size + 8}px;
      display: flex;
      align-items: center;
      justify-content: center;
    ">
      <div style="
        width: ${size}px;
        height: ${size}px;
        background: ${color};
        border-radius: 50%;
        border: 2px solid rgba(255,255,255,0.85);
        box-shadow: ${glow}, 0 2px 8px rgba(0,0,0,0.5);
        transition: transform 0.15s ease;
        cursor: pointer;
      "></div>
    </div>
  `;
}

function createClusterHTML(count) {
  const bgColor = count > 15 ? '#7C3AED' : count > 7 ? '#EF4444' : '#F59E0B';
  return `
    <div style="
      width: 38px; height: 38px;
      background: ${bgColor};
      border-radius: 50%;
      border: 2.5px solid rgba(255,255,255,0.8);
      display: flex; align-items: center; justify-content: center;
      font-family: 'DM Sans', sans-serif;
      font-weight: 600; font-size: 13px; color: white;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
      cursor: pointer;
    ">${count}</div>
  `;
}

function clusterEvents(events, distanceDeg) {
  const clusters = [];
  const assigned = new Set();

  events.forEach((ev, i) => {
    if (assigned.has(i) || !ev.lat || !ev.lon) return;
    const cluster = { events: [ev], lat: ev.lat, lon: ev.lon };
    assigned.add(i);

    events.forEach((other, j) => {
      if (assigned.has(j) || !other.lat || !other.lon) return;
      const dist = Math.hypot(ev.lat - other.lat, ev.lon - other.lon);
      if (dist < distanceDeg) {
        cluster.events.push(other);
        assigned.add(j);
      }
    });

    clusters.push(cluster);
  });

  return clusters;
}

function renderHeatmapCanvas(map, events, mode) {
  // Custom canvas overlay for heatmap
  const colors = {
    war:      ['rgba(255,50,50,0)', 'rgba(255,100,0,0.3)', 'rgba(255,0,0,0.6)'],
    science:  ['rgba(0,180,255,0)', 'rgba(0,100,255,0.3)', 'rgba(100,0,255,0.5)'],
    disaster: ['rgba(255,150,0,0)', 'rgba(255,100,0,0.3)', 'rgba(200,60,0,0.6)'],
    pandemic: ['rgba(0,200,100,0)', 'rgba(0,180,50,0.3)', 'rgba(0,120,50,0.6)'],
  };

  const CanvasLayer = window.L.Layer.extend({
    onAdd(map) {
      this._map = map;
      const size = map.getSize();
      this._canvas = window.L.DomUtil.create('canvas', 'heatmap-canvas-layer');
      this._canvas.width = size.x;
      this._canvas.height = size.y;
      this._canvas.style.position = 'absolute';
      this._canvas.style.left = '0';
      this._canvas.style.top = '0';
      this._canvas.style.pointerEvents = 'none';
      this._canvas.style.zIndex = '200';
      map.getPanes().overlayPane.appendChild(this._canvas);
      map.on('moveend zoomend', this._draw, this);
      this._draw();
    },
    onRemove(map) {
      map.off('moveend zoomend', this._draw, this);
      if (this._canvas) this._canvas.remove();
    },
    _draw() {
      if (!this._map) return;
      const ctx = this._canvas.getContext('2d');
      const size = this._map.getSize();
      this._canvas.width = size.x;
      this._canvas.height = size.y;
      ctx.clearRect(0, 0, size.x, size.y);

      events.forEach(ev => {
        const point = this._map.latLngToContainerPoint([ev.lat, ev.lon]);
        const radius = ev.impact === 'HIGH' ? 45 : 28;
        const grad = ctx.createRadialGradient(point.x, point.y, 0, point.x, point.y, radius);
        const c = colors[mode] || colors.war;
        grad.addColorStop(0, c[2]);
        grad.addColorStop(0.5, c[1]);
        grad.addColorStop(1, c[0]);
        ctx.beginPath();
        ctx.arc(point.x, point.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
      });
    }
  });

  const layer = new CanvasLayer();
  layer.addTo(map);
  heatmapLayerRef.current = layer;
}

// Need to expose ref for external access
const heatmapLayerRef = { current: null };
