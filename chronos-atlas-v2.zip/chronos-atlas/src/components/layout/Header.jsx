// src/components/layout/Header.jsx
import { motion } from 'framer-motion';
import { useFilterStore } from '../../store/filterStore';

export default function Header() {
  const { openSearch, toggleFilterPanel, toggleDiscovery, filterPanelOpen, discoveryOpen } = useFilterStore();

  return (
    <motion.header
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="app-header"
    >
      {/* Logo */}
      <div className="header-logo">
        <div className="logo-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#F59E0B" strokeWidth="1.5"/>
            <path d="M12 2C12 2 8 7 8 12C8 17 12 22 12 22" stroke="#F59E0B" strokeWidth="1.2"/>
            <path d="M12 2C12 2 16 7 16 12C16 17 12 22 12 22" stroke="#F59E0B" strokeWidth="1.2"/>
            <path d="M2 12H22" stroke="#F59E0B" strokeWidth="1.2"/>
            <path d="M3.5 7H20.5M3.5 17H20.5" stroke="#F59E0B" strokeWidth="0.8" opacity="0.6"/>
          </svg>
        </div>
        <div>
          <div className="logo-name">CHRONOS ATLAS</div>
          <div className="logo-sub">Navigate Human Civilization</div>
        </div>
      </div>

      {/* Controls */}
      <div className="header-controls">
        <button
          className={`header-btn ${filterPanelOpen ? 'active' : ''}`}
          onClick={toggleFilterPanel}
          title="Filters"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/>
            <line x1="11" y1="18" x2="13" y2="18"/>
          </svg>
          <span>Filter</span>
        </button>

        <button
          className="header-btn"
          onClick={openSearch}
          title="Search events (⌘K)"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
          </svg>
          <span>Search</span>
        </button>

        <button
          className={`header-btn ${discoveryOpen ? 'active' : ''}`}
          onClick={toggleDiscovery}
          title="Discovery Feed"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
          </svg>
          <span>Discover</span>
        </button>

        <div className="header-divider" />

        <div className="header-hint">
          <kbd>←→</kbd> navigate · <kbd>scroll</kbd> drag timeline
        </div>
      </div>
    </motion.header>
  );
}
