// src/components/heatmap/HeatmapControls.jsx
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { useFilterStore } from '../../store/filterStore';

const HEATMAP_MODES = [
  { id: 'war',      label: 'War Intensity',      icon: '⚔️',  color: '#EF4444', desc: 'Density of armed conflicts' },
  { id: 'science',  label: 'Innovation Density', icon: '🔬',  color: '#06B6D4', desc: 'Scientific discoveries & inventions' },
  { id: 'disaster', label: 'Disaster Zones',     icon: '🌋',  color: '#F97316', desc: 'Natural catastrophes & disasters' },
  { id: 'pandemic', label: 'Disease Spread',     icon: '🦠',  color: '#10B981', desc: 'Pandemics & epidemic outbreaks' },
];

export default function HeatmapControls() {
  const { showHeatmap, heatmapMode, setHeatmapMode, toggleHeatmap } = useFilterStore();
  const [expanded, setExpanded] = useState(false);

  const activeMode = HEATMAP_MODES.find(m => m.id === heatmapMode);

  return (
    <div className="heatmap-controls">
      {/* Expand toggle */}
      <motion.button
        className={`heatmap-toggle-btn ${showHeatmap ? 'active' : ''}`}
        onClick={() => {
          if (!expanded && !showHeatmap) setExpanded(true);
          else if (expanded) setExpanded(false);
          else toggleHeatmap();
        }}
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.96 }}
        style={{ '--hm-color': showHeatmap ? activeMode?.color : '#475569' }}
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M3 3v18h18"/>
          <path d="M7 16L11 10L15 14L19 6"/>
        </svg>
        <span>{showHeatmap ? 'Heatmap ON' : 'Heatmap'}</span>
        {showHeatmap && (
          <span className="hm-mode-badge" style={{ background: activeMode?.color }}>
            {activeMode?.icon}
          </span>
        )}
      </motion.button>

      {/* Mode selector */}
      <AnimatePresence>
        {(expanded || showHeatmap) && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 340, damping: 28 }}
            className="heatmap-mode-panel"
          >
            <div className="hm-panel-header">
              <span>Heatmap Mode</span>
              {showHeatmap && (
                <button className="hm-off-btn" onClick={() => { toggleHeatmap(); setExpanded(false); }}>
                  Turn Off
                </button>
              )}
            </div>
            <div className="hm-modes">
              {HEATMAP_MODES.map(mode => (
                <button
                  key={mode.id}
                  className={`hm-mode-btn ${heatmapMode === mode.id && showHeatmap ? 'active' : ''}`}
                  style={{ '--mode-color': mode.color }}
                  onClick={() => {
                    setHeatmapMode(mode.id);
                    setExpanded(false);
                  }}
                >
                  <span className="hm-mode-icon">{mode.icon}</span>
                  <div className="hm-mode-info">
                    <span className="hm-mode-name">{mode.label}</span>
                    <span className="hm-mode-desc">{mode.desc}</span>
                  </div>
                  {heatmapMode === mode.id && showHeatmap && (
                    <svg width="12" height="12" viewBox="0 0 10 8" fill="none">
                      <path d="M1 4L3.5 6.5L9 1" stroke={mode.color} strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                  )}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
