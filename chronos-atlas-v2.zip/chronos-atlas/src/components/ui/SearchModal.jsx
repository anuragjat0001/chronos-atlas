// src/components/ui/SearchModal.jsx
import { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useFilterStore } from '../../store/filterStore';
import { useTimelineStore } from '../../store/timelineStore';
import { HISTORICAL_EVENTS, getCategoryColor, getCategoryIcon } from '../../data/historicalEvents';
import { formatYear } from '../../lib/dateUtils';

function searchEvents(query) {
  if (!query || query.length < 2) return [];
  const q = query.toLowerCase();
  const results = HISTORICAL_EVENTS.filter(ev =>
    ev.title.toLowerCase().includes(q) ||
    ev.description.toLowerCase().includes(q) ||
    ev.country?.toLowerCase().includes(q) ||
    ev.tags?.some(t => t.includes(q))
  );
  // Sort: title match first, then by impact
  results.sort((a, b) => {
    const aTitle = a.title.toLowerCase().includes(q) ? 0 : 1;
    const bTitle = b.title.toLowerCase().includes(q) ? 0 : 1;
    if (aTitle !== bTitle) return aTitle - bTitle;
    const impactScore = { HIGH: 0, MEDIUM: 1, LOW: 2 };
    return (impactScore[a.impact] || 2) - (impactScore[b.impact] || 2);
  });
  return results.slice(0, 20);
}

export default function SearchModal({ onEventSelect }) {
  const { closeSearch } = useFilterStore();
  const { setYear } = useTimelineStore();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(0);
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') closeSearch();
      if (e.key === 'ArrowDown') setSelected(s => Math.min(s + 1, results.length - 1));
      if (e.key === 'ArrowUp') setSelected(s => Math.max(s - 1, 0));
      if (e.key === 'Enter' && results[selected]) {
        handleSelect(results[selected]);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [results, selected]);

  useEffect(() => {
    setResults(searchEvents(query));
    setSelected(0);
  }, [query]);

  const handleSelect = useCallback((ev) => {
    setYear(ev.year);
    onEventSelect(ev);
  }, [setYear, onEventSelect]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="search-backdrop"
      onClick={(e) => { if (e.target === e.currentTarget) closeSearch(); }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: -20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: -20 }}
        transition={{ type: 'spring', stiffness: 340, damping: 28 }}
        className="search-modal"
      >
        {/* Input */}
        <div className="search-input-row">
          <svg className="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
          </svg>
          <input
            ref={inputRef}
            type="text"
            className="search-input"
            placeholder="Search 5,000 years of history…"
            value={query}
            onChange={e => setQuery(e.target.value)}
            autoComplete="off"
          />
          {query && (
            <button className="search-clear" onClick={() => setQuery('')}>
              <svg width="14" height="14" viewBox="0 0 12 12" fill="none">
                <path d="M1 1L11 11M11 1L1 11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
              </svg>
            </button>
          )}
          <kbd className="search-kbd" onClick={closeSearch}>ESC</kbd>
        </div>

        {/* Results */}
        <div className="search-results">
          {query.length < 2 ? (
            <div className="search-hint">
              <div className="search-hint-categories">
                {['war', 'science', 'disaster', 'politics', 'exploration'].map(cat => (
                  <button
                    key={cat}
                    className="search-cat-chip"
                    style={{ '--chip-color': getCategoryColor(cat) }}
                    onClick={() => setQuery(cat)}
                  >
                    {getCategoryIcon(cat)} {cat}
                  </button>
                ))}
              </div>
              <p className="search-hint-text">Type to search events, countries, or topics</p>
            </div>
          ) : results.length === 0 ? (
            <div className="search-empty">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="1.5">
                <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
              </svg>
              <p>No events found for <strong>"{query}"</strong></p>
            </div>
          ) : (
            results.map((ev, i) => {
              const color = getCategoryColor(ev.category);
              return (
                <button
                  key={ev.id}
                  className={`search-result-item ${i === selected ? 'highlighted' : ''}`}
                  onClick={() => handleSelect(ev)}
                  onMouseEnter={() => setSelected(i)}
                >
                  <div className="sri-accent" style={{ background: color }} />
                  <div className="sri-body">
                    <div className="sri-top">
                      <span className="sri-year" style={{ color }}>
                        {formatYear(ev.year)}
                      </span>
                      <span className="sri-cat">{getCategoryIcon(ev.category)} {ev.category}</span>
                      <span className={`sri-impact sri-impact-${ev.impact.toLowerCase()}`}>
                        {ev.impact}
                      </span>
                    </div>
                    <div className="sri-title">{highlightMatch(ev.title, query)}</div>
                    {ev.country && (
                      <div className="sri-country">📍 {ev.country}</div>
                    )}
                  </div>
                  <svg className="sri-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </button>
              );
            })
          )}
        </div>

        {results.length > 0 && (
          <div className="search-footer">
            <span>{results.length} result{results.length !== 1 ? 's' : ''}</span>
            <span>↑↓ navigate · Enter select</span>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

function highlightMatch(text, query) {
  if (!query) return text;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark className="search-highlight">{text.slice(idx, idx + query.length)}</mark>
      {text.slice(idx + query.length)}
    </>
  );
}
