// src/components/ui/FilterPanel.jsx
import { motion } from 'framer-motion';
import { useFilterStore } from '../../store/filterStore';
import { CATEGORIES } from '../../data/historicalEvents';
import { HISTORICAL_EVENTS } from '../../data/historicalEvents';

// Pre-count events per category
const categoryCounts = CATEGORIES.reduce((acc, cat) => {
  acc[cat.slug] = HISTORICAL_EVENTS.filter(e => e.category === cat.slug).length;
  return acc;
}, {});

export default function FilterPanel() {
  const { activeCategories, toggleCategory, clearCategories } = useFilterStore();

  return (
    <motion.aside
      initial={{ x: -320, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -320, opacity: 0 }}
      transition={{ type: 'spring', stiffness: 280, damping: 28 }}
      className="filter-panel"
    >
      <div className="filter-panel-header">
        <h2 className="filter-title">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/>
            <line x1="11" y1="18" x2="13" y2="18"/>
          </svg>
          Categories
        </h2>
        {activeCategories.length > 0 && (
          <button className="filter-clear-btn" onClick={clearCategories}>
            Clear all
          </button>
        )}
      </div>

      <div className="filter-categories">
        {CATEGORIES.map(cat => {
          const isActive = activeCategories.includes(cat.slug);
          return (
            <button
              key={cat.slug}
              className={`filter-cat-btn ${isActive ? 'active' : ''}`}
              onClick={() => toggleCategory(cat.slug)}
              style={{ '--cat-color': cat.color }}
            >
              <div className="cat-btn-left">
                <span className="cat-icon">{cat.icon}</span>
                <span className="cat-label">{cat.label}</span>
              </div>
              <div className="cat-btn-right">
                <span className="cat-count">{categoryCounts[cat.slug] || 0}</span>
                <div className={`cat-check ${isActive ? 'checked' : ''}`}>
                  {isActive && (
                    <svg width="8" height="8" viewBox="0 0 10 8" fill="none">
                      <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="filter-legend">
        <div className="filter-legend-title">Impact Level</div>
        <div className="legend-items">
          {[
            { label: 'High Impact', color: '#EF4444', size: 14 },
            { label: 'Moderate', color: '#F59E0B', size: 10 },
            { label: 'Minor', color: '#6B7280', size: 7 },
          ].map(item => (
            <div key={item.label} className="legend-item">
              <div className="legend-dot" style={{
                width: item.size, height: item.size,
                background: item.color,
                borderRadius: '50%',
                border: '1.5px solid rgba(255,255,255,0.6)'
              }} />
              <span>{item.label}</span>
            </div>
          ))}
          <div className="legend-item">
            <div className="legend-cluster-sample">5</div>
            <span>Cluster</span>
          </div>
        </div>
      </div>

      <div className="filter-stats">
        <div className="fstat">
          <span className="fstat-val">{HISTORICAL_EVENTS.length}</span>
          <span className="fstat-lbl">total events</span>
        </div>
        <div className="fstat">
          <span className="fstat-val">
            {activeCategories.length === 0
              ? HISTORICAL_EVENTS.length
              : HISTORICAL_EVENTS.filter(e => activeCategories.includes(e.category)).length}
          </span>
          <span className="fstat-lbl">visible</span>
        </div>
        <div className="fstat">
          <span className="fstat-val">5,000+</span>
          <span className="fstat-lbl">years covered</span>
        </div>
      </div>
    </motion.aside>
  );
}
