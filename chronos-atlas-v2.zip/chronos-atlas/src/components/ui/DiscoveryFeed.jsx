// src/components/ui/DiscoveryFeed.jsx
import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useFilterStore } from '../../store/filterStore';
import { HISTORICAL_EVENTS, getCategoryColor, getCategoryIcon } from '../../data/historicalEvents';
import { DiscoveryEngine } from '../../lib/discoveryEngine';
import { formatYear } from '../../lib/dateUtils';

const WINDOW_SIZE = 50; // years visible in feed

export default function DiscoveryFeed({ currentYear, onEventClick }) {
  const { toggleDiscovery, isEventVisible } = useFilterStore();
  const [revealedEvents, setRevealedEvents] = useState([]);
  const engineRef = useRef(null);

  // Initialize discovery engine
  useEffect(() => {
    engineRef.current = new DiscoveryEngine(
      (ev) => {
        setRevealedEvents(prev => {
          const exists = prev.find(e => e.id === ev.id);
          if (exists) return prev;
          return [ev, ...prev].slice(0, 30); // keep last 30
        });
      },
      (retractedIds) => {
        setRevealedEvents(prev =>
          prev.filter(e => !retractedIds.includes(e.id))
        );
      }
    );
    return () => engineRef.current?.destroy();
  }, []);

  // Feed engine when year changes
  useEffect(() => {
    const yearEvents = HISTORICAL_EVENTS.filter(ev => {
      const inWindow = Math.abs(ev.year - currentYear) <= WINDOW_SIZE;
      return inWindow && isEventVisible(ev);
    });
    engineRef.current?.update(currentYear, yearEvents);
  }, [currentYear, isEventVisible]);

  return (
    <motion.aside
      initial={{ x: 320, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 320, opacity: 0 }}
      transition={{ type: 'spring', stiffness: 280, damping: 28 }}
      className="discovery-panel"
    >
      <div className="discovery-header">
        <div className="discovery-title">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" strokeWidth="2">
            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
          </svg>
          Discovery
        </div>
        <div className="discovery-subtitle">Scroll to reveal events</div>
        <button className="panel-close-btn" onClick={toggleDiscovery} aria-label="Close discovery panel">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M1 1L11 11M11 1L1 11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
        </button>
      </div>

      <div className="discovery-list">
        <AnimatePresence mode="popLayout" initial={false}>
          {revealedEvents.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="discovery-empty"
            >
              <div className="discovery-empty-icon">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#334155" strokeWidth="1.5">
                  <circle cx="12" cy="12" r="10"/>
                  <path d="M12 8v4M12 16h.01"/>
                </svg>
              </div>
              <p>Drag the timeline to reveal historical events</p>
            </motion.div>
          ) : (
            revealedEvents.map((ev) => (
              <DiscoveryCard
                key={ev.id}
                event={ev}
                onClick={() => onEventClick(ev)}
              />
            ))
          )}
        </AnimatePresence>
      </div>

      {revealedEvents.length > 0 && (
        <div className="discovery-footer">
          <button
            className="discovery-clear-btn"
            onClick={() => setRevealedEvents([])}
          >
            Clear feed
          </button>
        </div>
      )}
    </motion.aside>
  );
}

function DiscoveryCard({ event, onClick }) {
  const color = getCategoryColor(event.category);
  const icon = getCategoryIcon(event.category);

  return (
    <motion.button
      layout
      initial={{ opacity: 0, x: 40, scale: 0.94 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: 40, scale: 0.94 }}
      transition={{ type: 'spring', stiffness: 320, damping: 28 }}
      className="discovery-card"
      onClick={onClick}
      style={{ '--card-color': color }}
    >
      <div className="dc-accent" style={{ background: color }} />
      <div className="dc-body">
        <div className="dc-top">
          <span className="dc-icon">{icon}</span>
          <span className="dc-year" style={{ color }}>{formatYear(event.year)}</span>
          {event.impact === 'HIGH' && (
            <span className="dc-impact-badge">HIGH</span>
          )}
        </div>
        <div className="dc-title">{event.title}</div>
        {event.country && (
          <div className="dc-location">📍 {event.country}</div>
        )}
      </div>
      <svg className="dc-arrow" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
        <path d="M5 12h14M12 5l7 7-7 7"/>
      </svg>
    </motion.button>
  );
}
