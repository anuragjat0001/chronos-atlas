// src/components/timeline/EraLabel.jsx
import { motion, AnimatePresence } from 'framer-motion';
import { getEra } from '../../lib/dateUtils';

export default function EraLabel({ year }) {
  const era = getEra(year);
  return (
    <div className="era-label-wrapper">
      <AnimatePresence mode="wait">
        <motion.span
          key={era}
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 8 }}
          transition={{ duration: 0.25 }}
          className="era-label"
        >
          {era}
        </motion.span>
      </AnimatePresence>
    </div>
  );
}
