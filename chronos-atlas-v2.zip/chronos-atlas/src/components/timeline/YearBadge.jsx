// src/components/timeline/YearBadge.jsx
import { motion, AnimatePresence } from 'framer-motion';
import { formatYear, getEra } from '../../lib/dateUtils';

export default function YearBadge({ year }) {
  return (
    <div className="year-badge-wrapper">
      <AnimatePresence mode="popLayout">
        <motion.div
          key={year}
          initial={{ y: 8, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -8, opacity: 0 }}
          transition={{ duration: 0.12, ease: 'easeOut' }}
          className="year-badge"
        >
          {formatYear(year)}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// src/components/timeline/EraLabel.jsx — also export here
