// src/components/timeline/DensityBar.jsx
import { useRef, useEffect } from 'react';
import * as d3 from 'd3';
import { HISTORICAL_EVENTS, CATEGORIES } from '../../data/historicalEvents';

const MIN_YEAR = -3100;
const MAX_YEAR = 2024;
const BUCKET_SIZE = 25; // years per bucket

// Pre-compute density data once
const densityData = (() => {
  const buckets = {};
  for (let y = MIN_YEAR; y <= MAX_YEAR; y += BUCKET_SIZE) {
    buckets[y] = { year: y, total: 0 };
    CATEGORIES.forEach(c => { buckets[y][c.slug] = 0; });
  }
  HISTORICAL_EVENTS.forEach(ev => {
    const bucket = Math.floor(ev.year / BUCKET_SIZE) * BUCKET_SIZE;
    if (buckets[bucket]) {
      buckets[bucket].total++;
      if (buckets[bucket][ev.category] !== undefined) {
        buckets[bucket][ev.category]++;
      }
    }
  });
  return Object.values(buckets).sort((a, b) => a.year - b.year);
})();

export default function DensityBar({ currentYear, activeCategories }) {
  const svgRef = useRef(null);

  useEffect(() => {
    if (!svgRef.current) return;
    const container = svgRef.current.parentElement;
    const W = container.offsetWidth || 800;
    const H = 40;

    const svg = d3.select(svgRef.current)
      .attr('width', W)
      .attr('height', H);

    svg.selectAll('*').remove();

    const xScale = d3.scaleLinear()
      .domain([MIN_YEAR, MAX_YEAR])
      .range([0, W]);

    const data = activeCategories.length > 0
      ? densityData.map(d => ({
          ...d,
          total: activeCategories.reduce((sum, cat) => sum + (d[cat] || 0), 0)
        }))
      : densityData;

    const maxVal = d3.max(data, d => d.total) || 1;

    const yScale = d3.scaleLinear()
      .domain([0, maxVal])
      .range([H, 4]);

    // Draw area
    const area = d3.area()
      .x(d => xScale(d.year))
      .y0(H)
      .y1(d => yScale(d.total))
      .curve(d3.curveBasis);

    // Gradient
    const gradId = 'density-grad';
    const defs = svg.append('defs');
    const grad = defs.append('linearGradient')
      .attr('id', gradId)
      .attr('gradientUnits', 'userSpaceOnUse')
      .attr('x1', 0).attr('x2', 0)
      .attr('y1', 0).attr('y2', H);
    grad.append('stop').attr('offset', '0%').attr('stop-color', '#F59E0B').attr('stop-opacity', 0.55);
    grad.append('stop').attr('offset', '100%').attr('stop-color', '#F59E0B').attr('stop-opacity', 0.05);

    svg.append('path')
      .datum(data)
      .attr('d', area)
      .attr('fill', `url(#${gradId})`);

    // Line
    const line = d3.line()
      .x(d => xScale(d.year))
      .y(d => yScale(d.total))
      .curve(d3.curveBasis);

    svg.append('path')
      .datum(data)
      .attr('d', line)
      .attr('fill', 'none')
      .attr('stroke', '#F59E0B')
      .attr('stroke-width', 1.5)
      .attr('opacity', 0.7);

    // Current year line
    const cx = xScale(currentYear);
    svg.append('line')
      .attr('x1', cx).attr('x2', cx)
      .attr('y1', 0).attr('y2', H)
      .attr('stroke', '#F59E0B')
      .attr('stroke-width', 1)
      .attr('opacity', 0.5)
      .attr('stroke-dasharray', '2,3');

  }, [currentYear, activeCategories]);

  return (
    <div className="density-bar">
      <svg ref={svgRef} style={{ display: 'block', width: '100%', height: 40 }} />
    </div>
  );
}
