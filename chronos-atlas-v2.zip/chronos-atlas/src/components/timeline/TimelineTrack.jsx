// src/components/timeline/TimelineTrack.jsx
import { useRef, useEffect, useCallback, useState } from 'react';
import { useTimelineStore } from '../../store/timelineStore';
import { useFilterStore } from '../../store/filterStore';
import { InertiaEngine } from '../../lib/InertiaEngine';
import { HISTORICAL_EVENTS } from '../../data/historicalEvents';
import { formatYear, DECADE_MARKS } from '../../lib/dateUtils';
import DensityBar from './DensityBar';

const MIN_YEAR = -3100;
const MAX_YEAR = 2024;
const YEAR_RANGE = MAX_YEAR - MIN_YEAR;

export default function TimelineTrack() {
  const trackRef = useRef(null);
  const engineRef = useRef(null);
  const { currentYear, setYear } = useTimelineStore();
  const { activeCategories } = useFilterStore();
  const [isDragging, setIsDragging] = useState(false);
  const [velocity, setVelocity] = useState(0);

  // Initialize inertia engine
  useEffect(() => {
    engineRef.current = new InertiaEngine(
      currentYear,
      {
        friction: 0.88,
        minVelocity: 0.1,
        yearPerPixel: YEAR_RANGE / (window.innerWidth * 0.85),
        minYear: MIN_YEAR,
        maxYear: MAX_YEAR,
      },
      (year, vel) => {
        setYear(year);
        setVelocity(Math.abs(vel));
      }
    );

    // Keyboard navigation
    const onKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      engineRef.current?.onKeyDown(e.key);
    };
    window.addEventListener('keydown', onKey);

    return () => {
      engineRef.current?.destroy();
      window.removeEventListener('keydown', onKey);
    };
  }, []);

  const onPointerDown = useCallback((e) => {
    trackRef.current?.setPointerCapture(e.pointerId);
    engineRef.current?.onPointerDown(e.clientX);
    setIsDragging(true);
  }, []);

  const onPointerMove = useCallback((e) => {
    engineRef.current?.onPointerMove(e.clientX);
  }, []);

  const onPointerUp = useCallback(() => {
    engineRef.current?.onPointerUp();
    setIsDragging(false);
  }, []);

  const onWheel = useCallback((e) => {
    e.preventDefault();
    engineRef.current?.onWheel(e.deltaX, e.deltaY);
  }, []);

  const jumpToYear = useCallback((year) => {
    engineRef.current?.jumpToYear(year);
  }, []);

  const pct = ((currentYear - MIN_YEAR) / YEAR_RANGE) * 100;

  return (
    <div className="timeline-track-wrapper">
      {/* Density sparkline */}
      <DensityBar currentYear={currentYear} activeCategories={activeCategories} />

      {/* Main track */}
      <div
        ref={trackRef}
        className={`timeline-track ${isDragging ? 'is-dragging' : ''}`}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerLeave={onPointerUp}
        onWheel={onWheel}
        role="slider"
        aria-valuemin={MIN_YEAR}
        aria-valuemax={MAX_YEAR}
        aria-valuenow={currentYear}
        aria-label="Timeline year navigator"
        tabIndex={0}
      >
        {/* Track fill */}
        <div className="track-fill-bg" />
        <div
          className="track-fill-active"
          style={{
            width: `${pct}%`,
            opacity: isDragging ? 1 : 0.85,
          }}
        />

        {/* Decade markers */}
        {DECADE_MARKS.map(year => {
          const markerPct = ((year - MIN_YEAR) / YEAR_RANGE) * 100;
          const isMajor = year % 500 === 0 || year === 0;
          return (
            <div
              key={year}
              className={`decade-mark ${isMajor ? 'major' : 'minor'}`}
              style={{ left: `${markerPct}%` }}
              onClick={() => jumpToYear(year)}
              title={formatYear(year)}
            >
              <div className="decade-tick" />
              {isMajor && (
                <span className="decade-label">{formatYear(year)}</span>
              )}
            </div>
          );
        })}

        {/* Playhead */}
        <div
          className="track-playhead"
          style={{ left: `${pct}%` }}
        >
          <div className="playhead-line" />
          <div className={`playhead-diamond ${velocity > 5 ? 'fast' : ''}`} />
        </div>

        {/* Velocity indicator */}
        {velocity > 2 && (
          <div
            className="velocity-glow"
            style={{
              left: `${pct}%`,
              opacity: Math.min(velocity / 20, 0.6),
              width: `${Math.min(velocity * 3, 80)}px`,
            }}
          />
        )}
      </div>

      {/* Quick-jump decade dots */}
      <div className="quickjump-dots">
        {[-3000, -1000, 0, 500, 1000, 1500, 1700, 1800, 1900, 1950, 2000].map(year => (
          <button
            key={year}
            className={`qj-dot ${Math.abs(currentYear - year) < 30 ? 'active' : ''}`}
            onClick={() => jumpToYear(year)}
            title={formatYear(year)}
          >
            <span className="qj-dot-inner" />
            <span className="qj-label">{year < 0 ? `${Math.abs(year)}B` : year}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
