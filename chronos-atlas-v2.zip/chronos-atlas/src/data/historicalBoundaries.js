// CHRONOS ATLAS — Historical Boundary Data
// Simplified polygon outlines for major political entities across history

export const HISTORICAL_BOUNDARIES = [
  {
    id: 'egypt_old_kingdom',
    name: 'Ancient Egypt',
    yearStart: -3100,
    yearEnd: -332,
    color: '#D4AF37',
    opacity: 0.35,
    type: 'empire',
    coordinates: [
      [[24.7, 22.0], [36.9, 22.0], [36.9, 31.6], [34.5, 31.7], [32.5, 31.5],
       [29.0, 31.1], [25.0, 30.8], [24.7, 29.0], [24.7, 22.0]]
    ]
  },
  {
    id: 'assyrian_empire',
    name: 'Neo-Assyrian Empire',
    yearStart: -912,
    yearEnd: -609,
    color: '#8B4513',
    opacity: 0.35,
    type: 'empire',
    coordinates: [
      [[35.0, 29.0], [50.0, 29.0], [50.0, 38.0], [44.0, 41.0], [36.0, 37.0],
       [35.0, 34.0], [35.0, 29.0]]
    ]
  },
  {
    id: 'persian_achaemenid',
    name: 'Achaemenid Persian Empire',
    yearStart: -550,
    yearEnd: -330,
    color: '#C0392B',
    opacity: 0.3,
    type: 'empire',
    coordinates: [
      [[26.0, 22.0], [78.0, 22.0], [78.0, 32.0], [72.0, 38.0], [62.0, 42.0],
       [50.0, 42.0], [44.0, 41.0], [36.0, 37.0], [35.0, 34.0], [35.0, 29.0],
       [26.0, 22.0]]
    ]
  },
  {
    id: 'roman_republic',
    name: 'Roman Republic',
    yearStart: -509,
    yearEnd: -27,
    color: '#8B0000',
    opacity: 0.3,
    type: 'empire',
    coordinates: [
      [[-9.0, 36.0], [15.0, 36.0], [20.0, 38.0], [28.0, 41.0], [28.0, 46.0],
       [15.0, 48.0], [6.0, 47.0], [-2.0, 48.0], [-9.0, 44.0], [-9.0, 36.0]]
    ]
  },
  {
    id: 'roman_empire',
    name: 'Roman Empire',
    yearStart: -27,
    yearEnd: 395,
    color: '#CC0000',
    opacity: 0.28,
    type: 'empire',
    coordinates: [
      [[-9.0, 30.0], [38.0, 30.0], [42.0, 32.0], [42.0, 37.0], [36.0, 37.0],
       [28.0, 42.0], [28.0, 47.0], [24.0, 48.0], [17.0, 49.0], [7.0, 51.0],
       [-2.0, 51.0], [-5.5, 56.0], [-4.0, 58.0], [-3.0, 58.5], [0.0, 51.5],
       [-2.0, 51.0], [-4.0, 43.0], [-9.0, 43.5], [-6.0, 36.0], [-9.0, 30.0]]
    ]
  },
  {
    id: 'han_dynasty',
    name: 'Han Dynasty',
    yearStart: -206,
    yearEnd: 220,
    color: '#FFD700',
    opacity: 0.3,
    type: 'empire',
    coordinates: [
      [[73.0, 20.0], [123.0, 20.0], [123.0, 40.0], [135.0, 42.0], [130.0, 48.0],
       [115.0, 50.0], [98.0, 48.0], [88.0, 48.0], [80.0, 43.0], [73.0, 38.0],
       [73.0, 20.0]]
    ]
  },
  {
    id: 'byzantine_empire',
    name: 'Byzantine Empire',
    yearStart: 395,
    yearEnd: 1453,
    color: '#6A0DAD',
    opacity: 0.3,
    type: 'empire',
    coordinates: [
      [[22.0, 36.0], [42.0, 36.0], [44.0, 40.0], [40.0, 43.0], [32.0, 46.0],
       [22.0, 45.0], [20.0, 43.0], [18.0, 40.0], [22.0, 36.0]]
    ]
  },
  {
    id: 'umayyad_caliphate',
    name: 'Umayyad Caliphate',
    yearStart: 661,
    yearEnd: 750,
    color: '#2E8B57',
    opacity: 0.3,
    type: 'empire',
    coordinates: [
      [[-9.0, 35.0], [0.0, 35.0], [5.0, 36.0], [13.0, 37.0], [25.0, 38.0],
       [42.0, 37.0], [55.0, 36.0], [65.0, 33.0], [72.0, 28.0], [68.0, 22.0],
       [52.0, 12.0], [44.0, 14.0], [38.0, 15.0], [32.0, 22.0], [25.0, 22.0],
       [24.0, 30.0], [10.0, 30.0], [-2.0, 33.0], [-9.0, 35.0]]
    ]
  },
  {
    id: 'mongol_empire',
    name: 'Mongol Empire',
    yearStart: 1206,
    yearEnd: 1368,
    color: '#E07B39',
    opacity: 0.28,
    type: 'empire',
    coordinates: [
      [[24.0, 38.0], [45.0, 26.0], [56.0, 22.0], [72.0, 22.0], [82.0, 18.0],
       [105.0, 18.0], [117.0, 22.0], [122.0, 30.0], [135.0, 45.0], [130.0, 55.0],
       [115.0, 58.0], [95.0, 58.0], [78.0, 55.0], [62.0, 58.0], [48.0, 58.0],
       [38.0, 57.0], [32.0, 52.0], [24.0, 50.0], [22.0, 44.0], [24.0, 38.0]]
    ]
  },
  {
    id: 'ottoman_empire_peak',
    name: 'Ottoman Empire',
    yearStart: 1453,
    yearEnd: 1922,
    color: '#D4380D',
    opacity: 0.28,
    type: 'empire',
    coordinates: [
      [[-9.0, 29.0], [12.0, 29.0], [22.0, 29.0], [42.0, 22.0], [55.0, 22.0],
       [55.0, 38.0], [48.0, 42.0], [42.0, 42.0], [40.0, 47.0], [32.0, 47.0],
       [22.0, 46.0], [18.0, 43.0], [15.0, 43.0], [13.0, 43.0], [13.0, 37.0],
       [5.0, 37.0], [-5.0, 37.0], [-9.0, 36.0], [-9.0, 29.0]]
    ]
  },
  {
    id: 'mughal_empire',
    name: 'Mughal Empire',
    yearStart: 1526,
    yearEnd: 1857,
    color: '#4169E1',
    opacity: 0.3,
    type: 'empire',
    coordinates: [
      [[62.0, 22.0], [92.0, 22.0], [97.0, 28.0], [94.0, 32.0], [80.0, 34.0],
       [72.0, 36.0], [62.0, 35.0], [58.0, 32.0], [62.0, 22.0]]
    ]
  },
  {
    id: 'qing_dynasty',
    name: 'Qing Dynasty',
    yearStart: 1644,
    yearEnd: 1912,
    color: '#FFD700',
    opacity: 0.28,
    type: 'empire',
    coordinates: [
      [[73.0, 18.0], [135.0, 18.0], [135.0, 48.0], [132.0, 53.0], [118.0, 58.0],
       [100.0, 58.0], [80.0, 50.0], [73.0, 40.0], [73.0, 18.0]]
    ]
  },
  {
    id: 'british_empire',
    name: 'British Empire',
    yearStart: 1800,
    yearEnd: 1997,
    color: '#FF0000',
    opacity: 0.2,
    type: 'empire',
    // Simplified to key regions: India, Canada, Australia, South Africa
    multiPolygon: [
      // British Isles
      [[-8.0, 50.0], [2.0, 51.0], [2.0, 58.5], [-6.0, 58.5], [-8.0, 50.0]],
      // India
      [[62.0, 8.0], [92.0, 8.0], [92.0, 35.0], [62.0, 35.0], [62.0, 8.0]],
      // Canada (simplified south)
      [[-140.0, 49.0], [-53.0, 49.0], [-53.0, 70.0], [-140.0, 70.0], [-140.0, 49.0]],
      // Australia
      [[114.0, -38.0], [154.0, -38.0], [154.0, -16.0], [114.0, -16.0], [114.0, -38.0]],
      // South Africa
      [[16.5, -34.5], [33.0, -34.5], [33.0, -22.0], [16.5, -22.0], [16.5, -34.5]],
    ]
  },
  {
    id: 'napoleon_empire',
    name: 'French Empire (Napoleon)',
    yearStart: 1804,
    yearEnd: 1815,
    color: '#003399',
    opacity: 0.3,
    type: 'empire',
    coordinates: [
      [[-9.0, 36.0], [14.0, 36.0], [18.0, 40.0], [15.0, 44.0], [18.0, 48.0],
       [24.0, 52.0], [14.0, 54.0], [8.0, 54.0], [6.0, 51.0], [2.0, 51.0],
       [-2.0, 47.5], [-9.0, 44.0], [-9.0, 36.0]]
    ]
  },
  {
    id: 'soviet_union',
    name: 'Soviet Union (USSR)',
    yearStart: 1922,
    yearEnd: 1991,
    color: '#CC0000',
    opacity: 0.22,
    type: 'empire',
    coordinates: [
      [[22.0, 38.0], [55.0, 36.0], [62.0, 38.0], [74.0, 37.0], [82.0, 40.0],
       [90.0, 42.0], [112.0, 50.0], [130.0, 42.0], [141.0, 46.0], [170.0, 60.0],
       [180.0, 68.0], [170.0, 72.0], [140.0, 73.0], [100.0, 78.0], [62.0, 80.0],
       [28.0, 73.0], [24.0, 65.0], [22.0, 56.0], [22.0, 38.0]]
    ]
  },
  {
    id: 'usa_expansion',
    name: 'United States of America',
    yearStart: 1776,
    yearEnd: 2024,
    color: '#002868',
    opacity: 0.2,
    type: 'country',
    coordinates: [
      [[-124.0, 25.0], [-67.0, 25.0], [-67.0, 49.0], [-95.0, 49.0], [-124.0, 49.0],
       [-124.0, 32.0], [-117.0, 32.0], [-114.0, 25.0], [-124.0, 25.0]]
    ]
  },
];

export function getBoundariesForYear(year) {
  return HISTORICAL_BOUNDARIES.filter(b => year >= b.yearStart && year <= b.yearEnd);
}
