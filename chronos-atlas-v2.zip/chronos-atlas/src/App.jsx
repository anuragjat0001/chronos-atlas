// src/App.jsx
import { useState, useEffect, useCallback } from 'react';
import { AnimatePresence } from 'framer-motion';
import { useTimelineStore } from './store/timelineStore';
import { useFilterStore } from './store/filterStore';
import { HISTORICAL_EVENTS, getCategoryColor } from './data/historicalEvents';
import MapEngine from './components/map/MapEngine';
import TimelineTrack from './components/timeline/TimelineTrack';
import FilterPanel from './components/ui/FilterPanel';
import SearchModal from './components/ui/SearchModal';
import DiscoveryFeed from './components/ui/DiscoveryFeed';
import Header from './components/layout/Header';
import HeatmapControls from './components/heatmap/HeatmapControls';
import EventPopup from './components/map/EventPopup';
import YearBadge from './components/timeline/YearBadge';
import EraLabel from './components/timeline/EraLabel';
import './styles/globals.css';

export default function App() {
  const currentYear = useTimelineStore(s => s.currentYear);
  const { isEventVisible, searchOpen, filterPanelOpen, discoveryOpen } = useFilterStore();

  const [selectedEvent, setSelectedEvent] = useState(null);
  const [popupPosition, setPopupPosition] = useState({ x: 0, y: 0 });
  const [visibleEvents, setVisibleEvents] = useState([]);
  const [hoveredEvent, setHoveredEvent] = useState(null);

  // Compute visible events for current year ± window
  useEffect(() => {
    const windowSize = Math.abs(currentYear) > 1000 ? 50 : 15;
    const events = HISTORICAL_EVENTS.filter(e => {
      const inWindow = Math.abs(e.year - currentYear) <= windowSize;
      return inWindow && isEventVisible(e);
    });
    setVisibleEvents(events);
  }, [currentYear, isEventVisible]);

  const handleEventClick = useCallback((event, screenX, screenY) => {
    setSelectedEvent(event);
    // Smart popup positioning — keep within viewport
    const margin = 20;
    const popupW = 340;
    const popupH = 280;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const x = Math.min(Math.max(screenX - popupW / 2, margin), vw - popupW - margin);
    const y = Math.min(Math.max(screenY - popupH - 20, margin), vh - popupH - margin);
    setPopupPosition({ x, y });
  }, []);

  const handleClosePopup = useCallback(() => {
    setSelectedEvent(null);
  }, []);

  // Close popup on year change
  useEffect(() => {
    if (selectedEvent && Math.abs(selectedEvent.year - currentYear) > 60) {
      setSelectedEvent(null);
    }
  }, [currentYear, selectedEvent]);

  return (
    <div className="app-root">
      {/* Ambient background grid */}
      <div className="app-grid-bg" />

      {/* Header */}
      <Header />

      {/* Full-screen map */}
      <MapEngine
        events={visibleEvents}
        currentYear={currentYear}
        selectedEvent={selectedEvent}
        hoveredEvent={hoveredEvent}
        onEventClick={handleEventClick}
        onEventHover={setHoveredEvent}
      />

      {/* Filter panel — left side */}
      <AnimatePresence>
        {filterPanelOpen && <FilterPanel />}
      </AnimatePresence>

      {/* Discovery feed — right side */}
      <AnimatePresence>
        {discoveryOpen && (
          <DiscoveryFeed
            currentYear={currentYear}
            onEventClick={(ev) => handleEventClick(ev, window.innerWidth - 180, 300)}
          />
        )}
      </AnimatePresence>

      {/* Event popup */}
      <AnimatePresence>
        {selectedEvent && (
          <EventPopup
            event={selectedEvent}
            position={popupPosition}
            onClose={handleClosePopup}
          />
        )}
      </AnimatePresence>

      {/* Search modal */}
      <AnimatePresence>
        {searchOpen && (
          <SearchModal
            onEventSelect={(ev) => {
              useFilterStore.getState().closeSearch();
              handleEventClick(ev, window.innerWidth / 2, window.innerHeight / 2);
            }}
          />
        )}
      </AnimatePresence>

      {/* Bottom timeline */}
      <div className="timeline-container">
        <EraLabel year={currentYear} />
        <YearBadge year={currentYear} />
        <TimelineTrack />
      </div>

      {/* Heatmap controls — bottom right */}
      <HeatmapControls />

      {/* Stats bar */}
      <div className="stats-bar">
        <span className="stat-item">
          <span className="stat-dot" />
          {visibleEvents.length} events visible
        </span>
        <span className="stat-divider">·</span>
        <span className="stat-item">
          {HISTORICAL_EVENTS.length} total events
        </span>
      </div>
    </div>
  );
}
