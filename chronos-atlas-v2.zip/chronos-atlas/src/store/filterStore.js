// src/store/filterStore.js
import { create } from 'zustand';

export const useFilterStore = create((set, get) => ({
  activeCategories: [],   // empty = show all
  activeRegions: [],      // empty = show all
  showHeatmap: false,
  heatmapMode: 'war',     // 'war' | 'science' | 'disaster'
  searchQuery: '',
  searchOpen: false,
  discoveryOpen: true,
  filterPanelOpen: false,

  toggleCategory: (slug) => set((s) => {
    const cats = s.activeCategories.includes(slug)
      ? s.activeCategories.filter(c => c !== slug)
      : [...s.activeCategories, slug];
    return { activeCategories: cats };
  }),

  clearCategories: () => set({ activeCategories: [] }),

  setHeatmapMode: (mode) => set({ heatmapMode: mode, showHeatmap: true }),
  toggleHeatmap: () => set((s) => ({ showHeatmap: !s.showHeatmap })),

  setSearchQuery: (q) => set({ searchQuery: q }),
  openSearch: () => set({ searchOpen: true }),
  closeSearch: () => set({ searchOpen: false, searchQuery: '' }),

  toggleDiscovery: () => set((s) => ({ discoveryOpen: !s.discoveryOpen })),
  toggleFilterPanel: () => set((s) => ({ filterPanelOpen: !s.filterPanelOpen })),

  isEventVisible: (event) => {
    const { activeCategories } = get();
    if (activeCategories.length === 0) return true;
    return activeCategories.includes(event.category);
  },
}));
