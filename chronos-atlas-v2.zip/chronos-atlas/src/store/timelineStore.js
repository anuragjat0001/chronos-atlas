// src/store/timelineStore.js
import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

export const useTimelineStore = create(
  subscribeWithSelector((set, get) => ({
    currentYear: 1900,
    isPlaying: false,
    minYear: -3100,
    maxYear: 2024,
    yearRange: 5124,

    setYear: (year) => {
      const { minYear, maxYear } = get();
      set({ currentYear: Math.max(minYear, Math.min(maxYear, Math.round(year))) });
    },
    play: () => set({ isPlaying: true }),
    pause: () => set({ isPlaying: false }),
    togglePlay: () => set((s) => ({ isPlaying: !s.isPlaying })),
  }))
);
